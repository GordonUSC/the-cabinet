CTIN 290 | Monday September 21, 2026 | Unified student packet

Unzip the complete folder and open START-HERE.html.
Hamilton: official trailer. Team mood boards: 11:50-12:20, followed by feedback and revision.
The student guide, classroom slides, digital notes, sound and performance labs, mood-board studio, and assignment are included.
Local labs, notes, slides, PDFs and sound comparison film work offline. Course videos and worked examples require internet.
Video essay: September 24, 5 PM Pacific. Mood-board file: October 1, 5 PM Pacific. Team presentations: October 5, five minutes per team; everyone speaks.
No new submission for today’s practice.
